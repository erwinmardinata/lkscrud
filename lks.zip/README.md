# crud-ci3
Source code CRUD (Create, Read, Update, Delete) sederhana dengan framework CodeIgniter 3 dan database MariaDB.

Tutorial (Basic) : https://youtube.com/playlist?list=PLTagRbmJ8ettNR3gn7ssUjvIAy6YTSyiI

Studi kasus POS : https://youtube.com/playlist?list=PLTagRbmJ8etsYolfn4DTCg8I6rfDivklc
