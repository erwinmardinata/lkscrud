		</div>
		<div class="footer">
			Copyright <?php echo date('Y'); ?> - Lomba Kompetensi Siswa
		</div>
	</div>
</body>
</html>